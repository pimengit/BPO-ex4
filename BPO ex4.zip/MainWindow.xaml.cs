﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using Microsoft.Win32;
using BPO_ex4.StationLogic;
using BPO_ex4.Excel;
using BPO_ex4.ViewModels;

namespace BPO_ex4
{
    public partial class MainWindow : Window
    {
        private Context _ctx;
        private List<Node> _allNodesCache;
        private List<string> _uniqueTypes;
        private Node _currentNode;
        private string _loadedExcelPath;

        // История навигации (храним ID, чтобы не терять ссылку при перезагрузке)
        private Stack<string> _historyIds = new Stack<string>();

        // СЕССИЯ EXCEL (для быстрой записи)
        private ExcelSession _excelSession = new ExcelSession();

        public MainWindow()
        {
            OfficeOpenXml.ExcelPackage.License.SetNonCommercialPersonal("User");
            LogicAnalyzer.LoadAllFiles();

            InitializeComponent();
            _ctx = new Context();
            _ctx.Set("CONST_0", false);
            _ctx.Set("CONST_1", true);
        }

        // ==========================================
        //  ОТОБРАЖЕНИЕ ТАБЛИЦЫ
        // ==========================================
        private void RenderTable(Node node)
        {
            if (node == null) return;

            // История: если нода сменилась, пушим старый ID
            if (_currentNode != null && _currentNode.Id != node.Id)
            {
                _historyIds.Push(_currentNode.Id);
                BtnBack.IsEnabled = true;
            }
            _currentNode = node;

            // Шапка
            TxtNodeTitle.Text = node.Id;
            TxtNodeDesc.Text = node.Description;
            UpdateStatus();

            if (node.LogicSource is SheetLogic logic)
            {
                string sheetName = GetTypeName(node.Id);
                var truthTable = LogicAnalyzer.GetTruthTable(sheetName);

                // --- 1. ЗАГОЛОВКИ (Headers) ---
                var headers = new List<ColumnHeader>();
                for (int i = 1; i < logic.Groups.Length; i++)
                {
                    var group = logic.Groups[i];
                    if (group == null || group.Count == 0) continue;

                    string opType = LogicAnalyzer.GetGroupType(sheetName, i);
                    if (string.IsNullOrEmpty(opType))
                        opType = (group.Count > 1) ? "AND" : "V";

                    // ВАЖНО: Берем ноды из _ctx.Get(), чтобы они были свежими
                    var wrappers = group.Select(n => new NodeWrapper { LogicNode = _ctx.Get(n.Id) }).ToList();

                    headers.Add(new ColumnHeader
                    {
                        GroupIndex = i,
                        Title = GetTypeName(group[0].Id),
                        OperatorType = opType,
                        Nodes = wrappers
                    });
                }
                IcHeaders.ItemsSource = headers;

                // --- 2. СТРОКИ (Truth Table) ---
                var rowVMs = new List<TableRowViewModel>();
                foreach (var row in truthTable)
                {
                    var vm = new TableRowViewModel { RowId = row.RowIndex };
                    bool rowActive = true;

                    foreach (var col in headers)
                    {
                        var cell = new TableCell { Text = "" };

                        if (row.Cells.TryGetValue(col.GroupIndex, out string req))
                        {
                            cell.Text = req; // "1" или "0"

                            // Проверка
                            bool currentVal = false;
                            if (col.OperatorType == "OR")
                                currentVal = col.Nodes.Any(n => n.Value); // Value берется из LogicNode
                            else
                                currentVal = col.Nodes.All(n => n.Value);

                            bool requiredVal = (req == "1");
                            if (currentVal != requiredVal) rowActive = false;
                        }
                        vm.Cells.Add(cell);
                    }

                    if (vm.Cells.All(c => c.IsEmpty)) rowActive = false;
                    vm.IsRowActive = rowActive;
                    rowVMs.Add(vm);
                }
                IcRows.ItemsSource = rowVMs;
            }
            else
            {
                IcHeaders.ItemsSource = null;
                IcRows.ItemsSource = null;
            }
        }

        private void UpdateStatus()
        {
            if (_currentNode == null) return;
            // Читаем значение прямо перед отрисовкой
            bool val = _currentNode.Value;
            TxtNodeValue.Text = val ? "TRUE" : "FALSE";
            TxtNodeValue.Foreground = val ? Brushes.LimeGreen : Brushes.Red;
        }

        // ==========================================
        //  ИНТЕРАКТИВ (КЛИКИ)
        // ==========================================

        // ЛКМ: Провалиться
        private void BtnVar_LeftClick(object sender, RoutedEventArgs e)
        {
            if ((sender as Button).Tag is Node n)
            {
                // Ищем свежую версию ноды в контексте
                RenderTable(_ctx.Get(n.Id));
            }
        }

        // ПКМ: Изменить значение (Toggle)
        private void CtxToggle_Click(object sender, RoutedEventArgs e)
        {
            if ((sender as MenuItem).Tag is Node n)
            {
                ChangeVariableValue(n);
            }
        }

        // Тоже ПКМ, но через кнопку (на случай если меню не сработает)
        private void BtnVar_RightClick(object sender, MouseButtonEventArgs e)
        {
            if ((sender as Button).Tag is Node n)
            {
                ChangeVariableValue(n);
            }
        }

        // Централизованный метод смены значения
        private void ChangeVariableValue(Node n)
        {
            if (n.Id.StartsWith("CONST"))
            {
                MessageBox.Show("Cannot change CONST!");
                return;
            }

            // 1. Меняем в контексте
            _ctx.Set(n.Id, !n.Value);

            // 2. Запускаем волну пересчета
            _ctx.RecomputeAll();

            // 3. Обновляем экран
            // Делаем это принудительно для текущей ноды, чтобы перерисовались цвета
            if (_currentNode != null) RenderTable(_currentNode);
        }

        // ==========================================
        //  РЕДАКТИРОВАНИЕ (EXCEL SESSION)
        // ==========================================

        // Кнопка "+"
        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn && btn.Tag is int groupIdx)
            {
                OpenEditWindow(groupIdx, -1);
            }
        }

        // Меню "Edit"
        private void CtxEdit_Click(object sender, RoutedEventArgs e)
        {
            if ((sender as MenuItem).Tag is Node clickedNode)
            {
                var (groupIdx, inputIdx) = FindInputIndices(_currentNode, clickedNode);
                if (groupIdx != -1) OpenEditWindow(groupIdx, inputIdx);
            }
        }

        // Меню "Add"
        private void CtxAdd_Click(object sender, RoutedEventArgs e)
        {
            if (int.TryParse((sender as MenuItem).Tag?.ToString(), out int g)) OpenEditWindow(g, -1);
        }

        private void OpenEditWindow(int groupIdx, int inputIdx)
        {
            if (!_excelSession.IsLoaded) { MessageBox.Show("Load file first!"); return; }

            // Передаем сессию и список нод
            var win = new EditNodeWindow(_currentNode, groupIdx, inputIdx, _excelSession, _allNodesCache);

            if (win.ShowDialog() == true)
            {
                // Если нажали Save в окне:
                // 1. Сохраняем сессию на диск (это быстро, т.к. файл открыт)
                Mouse.OverrideCursor = Cursors.Wait;
                try
                {
                    _excelSession.Save(); // Физ. запись на диск

                    // 2. Перезагружаем контекст
                    ReloadData();
                }
                finally
                {
                    Mouse.OverrideCursor = null;
                }
            }
        }

        // ==========================================
        //  ЗАГРУЗКА
        // ==========================================
        private void BtnLoad_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new OpenFileDialog { Filter = "Excel Files|*.xlsx" };
            if (dlg.ShowDialog() == true)
            {
                _loadedExcelPath = dlg.FileName;
                try
                {
                    // Инициализируем сессию
                    _excelSession.Load(_loadedExcelPath);
                    ReloadData();
                }
                catch (Exception ex) { MessageBox.Show("File locked or error: " + ex.Message); }
            }
        }

        private void ReloadData()
        {
            try
            {
                var newCtx = new Context();
                newCtx.Set("CONST_0", false);
                newCtx.Set("CONST_1", true);

                // Читаем с диска (куда мы только что сохранили через Session)
                ExcelParser.Load(_loadedExcelPath, newCtx);
                newCtx.RecomputeAll();

                _ctx = newCtx; // Подменяем мозг

                _allNodesCache = _ctx.GetAllNodes().OrderBy(n => n.Id).ToList();
                _uniqueTypes = _allNodesCache.Select(n => GetTypeName(n.Id)).Distinct().OrderBy(s => s).ToList();
                LstTypes.ItemsSource = _uniqueTypes;

                // Восстанавливаем вид
                if (_currentNode != null)
                {
                    // Ищем эту же ноду в НОВОМ контексте
                    var freshNode = _ctx.Get(_currentNode.Id);
                    RenderTable(freshNode);
                }
                else
                {
                    IcHeaders.ItemsSource = null;
                    IcRows.ItemsSource = null;
                }
            }
            catch (Exception ex) { MessageBox.Show("Reload Error: " + ex.Message); }
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            if (_historyIds.Count > 0)
            {
                string prevId = _historyIds.Pop();
                var node = _ctx.Get(prevId);
                RenderTable(node);

                // Убираем дубль из стека
                if (_historyIds.Count > 0 && _historyIds.Peek() == prevId) _historyIds.Pop();

                BtnBack.IsEnabled = _historyIds.Count > 0;
            }
        }

        // --- Helpers ---
        private (int groupIdx, int inputIdx) FindInputIndices(Node center, Node input)
        {
            if (center.LogicSource is SheetLogic logic)
            {
                for (int i = 1; i < logic.Groups.Length; i++)
                {
                    var group = logic.Groups[i];
                    if (group == null) continue;
                    for (int k = 0; k < group.Count; k++)
                    {
                        if (group[k].Id == input.Id) return (i, k);
                    }
                }
            }
            return (-1, -1);
        }

        private string GetTypeName(string id) => id.Contains('[') ? id.Substring(0, id.IndexOf('[')) : id;
        private void TxtSearchType_TextChanged(object sender, TextChangedEventArgs e) { if (_uniqueTypes != null) LstTypes.ItemsSource = _uniqueTypes.Where(t => t.ToLower().Contains(TxtSearchType.Text.ToLower())).ToList(); }
        private void LstTypes_SelectionChanged(object sender, SelectionChangedEventArgs e) { if (LstTypes.SelectedItem is string t) LstInstances.ItemsSource = _allNodesCache.Where(n => GetTypeName(n.Id) == t).OrderBy(n => n.Id).ToList(); }
        private void LstInstances_SelectionChanged(object sender, SelectionChangedEventArgs e) { if (LstInstances.SelectedItem is Node n) RenderTable(n); }

        // Закрываем сессию при выходе
        protected override void OnClosed(EventArgs e)
        {
            _excelSession.Dispose();
            base.OnClosed(e);
        }
    }

    // Тот самый конвертер
    public class ConstCheckConverter : System.Windows.Data.IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (value is string id) return id.StartsWith("CONST", StringComparison.OrdinalIgnoreCase);
            return false;
        }
        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture) => throw new NotImplementedException();
    }
}