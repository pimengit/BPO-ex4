using System;
using BPO_ex4.StationLogic;

namespace BPO_ex4.LogicSheets
{
    class ROUTE_VAM : SheetLogic
    {
        public ROUTE_VAM()
        {
            OnDelay  = TimeSpan.FromMilliseconds(50);
            OffDelay = TimeSpan.FromMilliseconds(50);
        }

        public override bool Compute()
        {
            return (V(3) && V(4) && V(6)) || (V(3) && V(4) && V(5)) || (!OR(1) && !V(2) && !V(3));
        }
    }
}
