using System;
using BPO_ex4.StationLogic;

namespace BPO_ex4.LogicSheets
{
    class RELAY_NRK1 : SheetLogic
    {
        public RELAY_NRK1()
        {
            OnDelay  = TimeSpan.FromMilliseconds(600);
            OffDelay = TimeSpan.FromMilliseconds(50);
        }

        public override bool Compute()
        {
            return (V(1) && !V(5) && !V(6)) || (V(2) && !V(5) && !V(6)) || (V(5) && V(6)) || (V(3) && !V(4)) || (!V(3) && V(4));
        }
    }
}
