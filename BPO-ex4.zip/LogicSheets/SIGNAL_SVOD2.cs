using System;
using BPO_ex4.StationLogic;

namespace BPO_ex4.LogicSheets
{
    class SIGNAL_SVOD2 : SheetLogic
    {
        public SIGNAL_SVOD2()
        {
            OnDelay  = TimeSpan.FromMilliseconds(50);
            OffDelay = TimeSpan.FromMilliseconds(50);
        }

        public override bool Compute()
        {
            return (V(1) && OR(2) && !V(3) && V(4)) || (V(5) && V(6)) || (!V(1) && OR(2) && !V(3) && !V(4));
        }
    }
}
