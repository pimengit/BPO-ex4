using System;
using BPO_ex4.StationLogic;

namespace BPO_ex4.LogicSheets
{
    class SIGNAL_APS : SheetLogic
    {
        public SIGNAL_APS()
        {
            OnDelay  = TimeSpan.FromMilliseconds(30000);
            OffDelay = TimeSpan.FromMilliseconds(50);
        }

        public override bool Compute()
        {
            return (V(1) && !V(2) && !V(3));
        }
    }
}
