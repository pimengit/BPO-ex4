﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace BPO_ex4.StationLogic
{
    public static class DeepAnalyzer
    {
        // Класс для статистики по каждой переменной
        private class NodeStat
        {
            public bool SawTrue = false;
            public bool SawFalse = false;
        }

        public static List<string> Analyze(Context ctx)
        {
            var report = new List<string>();
            var allNodes = ctx.GetAllNodes().ToList();

            // 1. БЭКАП (Сохраняем состояние UI)
            var backup = allNodes.ToDictionary(n => n, n => n.Value);

            // ------------------------------------------------------------
            // ЭТАП 1: КЛАССИФИКАЦИЯ
            // ------------------------------------------------------------
            var inputs = new List<Node>();   // Рычаги (Кнопки, Входы)
            var logics = new List<Node>();   // Логика (То, что вычисляется)

            foreach (var n in allNodes)
            {
                // Если это Константа 1 - включаем её навечно
                if (IsConstantOne(n.Id))
                {
                    n.Value = true;
                }
                // Если это Константа 0 - выключаем
                else if (IsConstantZero(n.Id))
                {
                    n.Value = false;
                }
                // Если это Внешний Вход - запоминаем в список "Рычагов"
                else if (IsExternalInput(n.Id))
                {
                    inputs.Add(n);
                    n.Value = false; // Сброс
                }
                // Если это Логика (есть формула)
                else if (n.Compute != null)
                {
                    logics.Add(n);
                    n.Value = false; // Сброс в 0 (Холодный старт)
                }
            }

            // Создаем статистику для всех логических переменных
            var stats = logics.ToDictionary(n => n, n => new NodeStat());

            // ------------------------------------------------------------
            // ЭТАП 2: ХАОС (СИМУЛЯЦИЯ)
            // ------------------------------------------------------------
            var rand = new Random();
            int cycles = 3000; // Количество тактов симуляции (чем больше, тем точнее)

            // Крутим цикл жизни станции
            for (int i = 0; i < cycles; i++)
            {
                // А. МЕНЯЕМ ВХОДЫ (Рандомно тыкаем кнопки)
                // Не меняем все сразу, меняем ~10% входов за такт, имитируя работу
                foreach (var inp in inputs)
                {
                    if (rand.NextDouble() < 0.1) // 10% шанс переключения
                    {
                        inp.Value = !inp.Value;
                    }
                }

                // Б. ВОЛНА ЛОГИКИ
                // Прогоняем вычисления несколько раз, чтобы сигнал успел пройти по цепочке A->B->C
                for (int pass = 0; pass < 5; pass++)
                {
                    foreach (var node in logics)
                    {
                        try
                        {
                            node.Value = node.Compute();
                        }
                        catch { }
                    }
                }

                // В. ЗАПИСЬ СТАТИСТИКИ
                foreach (var kvp in stats)
                {
                    if (kvp.Key.Value) kvp.Value.SawTrue = true;
                    else kvp.Value.SawFalse = true;
                }
            }

            // ------------------------------------------------------------
            // ЭТАП 3: АНАЛИЗ РЕЗУЛЬТАТОВ
            // ------------------------------------------------------------
            int deadCount = 0;
            int stuckCount = 0;

            foreach (var kvp in stats)
            {
                var node = kvp.Key;
                var stat = kvp.Value;

                // Фильтруем мусор, показываем только "Реальные" переменные (Лист[Число])
                if (!IsRealVariable(node.Id)) continue;

                if (!stat.SawTrue)
                {
                    deadCount++;
                    // Пробуем понять причину для отчета (упрощенно)
                    string hint = HasSelfReference(node) ? " (Самоблокировка без пуска?)" : "";
                    report.Add($"[DEAD] {node.Id} {node.Description} -> Всегда 0.{hint}");
                }
                else if (!stat.SawFalse)
                {
                    stuckCount++;
                    report.Add($"[STUCK] {node.Id} {node.Description} -> Всегда 1 (Залипла).");
                }
            }

            // ------------------------------------------------------------
            // 4. ВОССТАНОВЛЕНИЕ UI
            // ------------------------------------------------------------
            foreach (var kvp in backup)
            {
                kvp.Key.Value = kvp.Value;
            }

            if (deadCount == 0 && stuckCount == 0)
            {
                report.Add("Отлично! Все переменные работают (меняют значения при изменении входов).");
            }
            else
            {
                report.Add($"\nСтатистика:\nМертвых (0): {deadCount}\nЗалипших (1): {stuckCount}");
            }
            report.Add($"Прогнано {cycles} циклов симуляции.");

            return report;
        }

        // --- ХЕЛПЕРЫ ---

        private static bool IsRealVariable(string id)
        {
            // Исключаем диапазоны [1:5] и прочий мусор, оставляем V[1], ROUTE[5]
            if (id.Contains(":")) return false;
            return Regex.IsMatch(id, @"^.+\[\d+\]$");
        }

        // Проверка на самоблокировку (V зависит от V)
        private static bool HasSelfReference(Node node)
        {
            if (node.LogicSource?.Groups == null) return false;
            foreach (var g in node.LogicSource.Groups)
            {
                if (g != null && g.Any(n => n.Id == node.Id)) return true;
            }
            return false;
        }

        private static bool IsExternalInput(string id)
        {
            var u = id.ToUpper();
            return u.Contains(":");
        }

        private static bool IsConstantOne(string id)
        {
            var u = id.ToUpper();
            return u == "CONST_1";
        }

        private static bool IsConstantZero(string id)
        {
            var u = id.ToUpper();
            return u == "CONST_0";
        }
    }
}